import { MessageCircle } from "lucide-react";

export default function WhatsAppButton() {
  // WhatsApp number: 01034009418 (Egypt format)
  // Convert to international format for WhatsApp API: +201034009418
  const whatsappNumber = "201034009418";
  const whatsappUrl = `https://wa.me/${whatsappNumber}?text=مرحبا%20بي%20في%20Smart%20Venom%20K`;

  return (
    <a
      href={whatsappUrl}
      target="_blank"
      rel="noopener noreferrer"
      title="تواصل معنا عبر WhatsApp: 01034009418"
      className="fixed bottom-6 left-6 z-40 group"
    >
      <div className="relative">
        {/* Animated pulse ring */}
        <div className="absolute inset-0 rounded-full bg-neon-green/20 animate-pulse"></div>
        
        {/* Main button */}
        <button className="relative w-14 h-14 rounded-full bg-gradient-to-br from-neon-green to-emerald-500 flex items-center justify-center shadow-lg hover:shadow-2xl hover:scale-110 transition-all duration-300 group-hover:from-emerald-500 group-hover:to-neon-green">
          <MessageCircle className="w-7 h-7 text-white" />
        </button>
        
        {/* Tooltip */}
        <div className="absolute left-full ml-3 bottom-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
          <div className="glass-card px-4 py-2 rounded text-sm text-text-primary border border-border whitespace-nowrap">
            تواصل معنا
            <div className="absolute right-full mr-2 top-1/2 -translate-y-1/2 w-2 h-2 bg-neon-green rounded-full"></div>
          </div>
        </div>
      </div>
    </a>
  );
}
