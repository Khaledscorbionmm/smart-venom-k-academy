import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure, adminProcedure } from "./_core/trpc";
import { z } from "zod";
import {
  getCourses,
  getCourseById,
  getLessonsByCourseId,
  getLessonById,
  validatePromoCode,
  markPromoCodeUsed,
  getUserProgress,
  getUserCourseProgress,
  getUserStats,
  createUserStats,
  getDb,
} from "./db";
import { userProgress, userStats } from "../drizzle/schema";
import { eq, and } from "drizzle-orm";

export const appRouter = router({
  system: systemRouter,
  
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Courses router
  courses: router({
    list: protectedProcedure.query(async () => {
      return getCourses();
    }),
    
    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return getCourseById(input.id);
      }),
  }),

  // Lessons router
  lessons: router({
    getByCourseId: protectedProcedure
      .input(z.object({ courseId: z.number() }))
      .query(async ({ input }) => {
        return getLessonsByCourseId(input.courseId);
      }),
    
    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return getLessonById(input.id);
      }),
    
    markComplete: protectedProcedure
      .input(z.object({ lessonId: z.number(), xpEarned: z.number().optional() }))
      .mutation(async ({ input, ctx }) => {
        const db = await getDb();
        if (!db) return { success: false };
        
        try {
          const xp = input.xpEarned || 100;
          
          // Check if already completed
          const existing = await getUserProgress(ctx.user!.id, input.lessonId);
          
          if (existing?.isCompleted) {
            return { success: true, alreadyCompleted: true };
          }
          
          // Mark lesson as complete
          if (existing) {
            await db.update(userProgress)
              .set({ isCompleted: 1, xpEarned: xp, completedAt: new Date() })
              .where(and(
                eq(userProgress.userId, ctx.user!.id),
                eq(userProgress.lessonId, input.lessonId)
              ));
          } else {
            await db.insert(userProgress).values({
              userId: ctx.user!.id,
              lessonId: input.lessonId,
              isCompleted: 1,
              xpEarned: xp,
              completedAt: new Date(),
            });
          }
          
          // Update user stats
          let stats = await getUserStats(ctx.user!.id);
          if (!stats) {
            await createUserStats(ctx.user!.id);
            stats = await getUserStats(ctx.user!.id);
          }
          
          if (stats) {
            const newTotalXp = (stats.totalXp || 0) + xp;
            const today = new Date().toDateString();
            const lastActivity = stats.lastActivityDate ? new Date(stats.lastActivityDate).toDateString() : null;
            const isNewDay = lastActivity !== today;
            
            const newStreak = isNewDay ? (stats.currentStreak || 0) + 1 : stats.currentStreak || 1;
            const longestStreak = Math.max(newStreak, stats.longestStreak || 0);
            
            await db.update(userStats)
              .set({
                totalXp: newTotalXp,
                currentStreak: newStreak,
                longestStreak: longestStreak,
                lastActivityDate: new Date(),
              })
              .where(eq(userStats.userId, ctx.user!.id));
          }
          
          return { success: true };
        } catch (error) {
          console.error("Error marking lesson complete:", error);
          return { success: false };
        }
      }),
  }),

  // User stats router
  stats: router({
    getMyStats: protectedProcedure.query(async ({ ctx }) => {
      const stats = await getUserStats(ctx.user!.id);
      return stats || { userId: ctx.user!.id, totalXp: 0, currentStreak: 0, longestStreak: 0 };
    }),
    
    getCourseProgress: protectedProcedure
      .input(z.object({ courseId: z.number() }))
      .query(async ({ input, ctx }) => {
        return getUserCourseProgress(ctx.user!.id, input.courseId);
      }),
  }),

  // Admin router
  admin: router({
    // Promo code management
    createPromoCode: adminProcedure
      .input(z.object({ code: z.string() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) return { success: false };
        
        try {
          const { promoCodes } = await import("../drizzle/schema");
          await db.insert(promoCodes).values({ code: input.code });
          return { success: true };
        } catch {
          return { success: false };
        }
      }),
    
    getPromoCodes: adminProcedure.query(async () => {
      const db = await getDb();
      if (!db) return [];
      
      const { promoCodes } = await import("../drizzle/schema");
      return db.select().from(promoCodes);
    }),
    
    // Course management
    createCourse: adminProcedure
      .input(z.object({
        title: z.string(),
        description: z.string().optional(),
        level: z.enum(["beginner", "intermediate", "advanced"]),
        icon: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) return { success: false };
        
        try {
          const { courses } = await import("../drizzle/schema");
          await db.insert(courses).values(input);
          return { success: true };
        } catch {
          return { success: false };
        }
      }),
    
    updateCourse: adminProcedure
      .input(z.object({
        id: z.number(),
        title: z.string().optional(),
        description: z.string().optional(),
        level: z.enum(["beginner", "intermediate", "advanced"]).optional(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) return { success: false };
        
        try {
          const { courses } = await import("../drizzle/schema");
          const { id, ...data } = input;
          await db.update(courses).set(data).where(eq(courses.id, id));
          return { success: true };
        } catch {
          return { success: false };
        }
      }),
    
    // Lesson management
    createLesson: adminProcedure
      .input(z.object({
        courseId: z.number(),
        title: z.string(),
        content: z.string().optional(),
        codeExample: z.string().optional(),
        xpReward: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) return { success: false };
        
        try {
          const { lessons } = await import("../drizzle/schema");
          await db.insert(lessons).values(input);
          return { success: true };
        } catch {
          return { success: false };
        }
      }),
    
    updateLesson: adminProcedure
      .input(z.object({
        id: z.number(),
        title: z.string().optional(),
        content: z.string().optional(),
        codeExample: z.string().optional(),
        xpReward: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) return { success: false };
        
        try {
          const { lessons } = await import("../drizzle/schema");
          const { id, ...data } = input;
          await db.update(lessons).set(data).where(eq(lessons.id, id));
          return { success: true };
        } catch {
          return { success: false };
        }
      }),
    
    // Statistics
    getStats: adminProcedure.query(async () => {
      const db = await getDb();
      if (!db) return { totalUsers: 0, totalCourses: 0, totalLessons: 0 };
      
      try {
        const { users, courses, lessons } = await import("../drizzle/schema");
        const userCount = await db.select().from(users);
        const courseCount = await db.select().from(courses);
        const lessonCount = await db.select().from(lessons);
        
        return {
          totalUsers: userCount.length,
          totalCourses: courseCount.length,
          totalLessons: lessonCount.length,
        };
      } catch {
        return { totalUsers: 0, totalCourses: 0, totalLessons: 0 };
      }
    }),
  }),
});

export type AppRouter = typeof appRouter;
