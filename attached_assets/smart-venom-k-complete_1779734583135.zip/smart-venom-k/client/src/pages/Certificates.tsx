import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Award, Download, Share2, Trophy, Star } from "lucide-react";
import { useLocation } from "wouter";
import { useState } from "react";
import { toast } from "sonner";

interface Certificate {
  id: number;
  courseTitle: string;
  level: string;
  completionDate: string;
  certificateNumber: string;
  score: number;
}

interface Achievement {
  id: number;
  title: string;
  description: string;
  icon: string;
  unlockedDate: string;
  rarity: "common" | "rare" | "epic" | "legendary";
}

export default function Certificates() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState("certificates");

  // Mock certificates data
  const certificates: Certificate[] = [
    {
      id: 1,
      courseTitle: "Python للمبتدئين",
      level: "مبتدئ",
      completionDate: "2026-05-20",
      certificateNumber: "SVK-2026-001",
      score: 95,
    },
    {
      id: 2,
      courseTitle: "English Beginners A1",
      level: "مبتدئ",
      completionDate: "2026-05-15",
      certificateNumber: "SVK-2026-002",
      score: 88,
    },
  ];

  // Mock achievements data
  const achievements: Achievement[] = [
    {
      id: 1,
      title: "البداية القوية",
      description: "أكمل أول دورة بنجاح",
      icon: "🚀",
      unlockedDate: "2026-05-20",
      rarity: "common",
    },
    {
      id: 2,
      title: "المتعلم المجتهد",
      description: "أكمل 5 دورات",
      icon: "📚",
      unlockedDate: "2026-05-18",
      rarity: "rare",
    },
    {
      id: 3,
      title: "النجم الصاعد",
      description: "احصل على 90+ في 3 دورات",
      icon: "⭐",
      unlockedDate: "2026-05-15",
      rarity: "epic",
    },
    {
      id: 4,
      title: "الخبير",
      description: "أكمل دورة متقدمة",
      icon: "🏆",
      unlockedDate: "2026-05-10",
      rarity: "legendary",
    },
  ];

  const handleDownloadCertificate = (cert: Certificate) => {
    toast.success(`تم تحميل الشهادة: ${cert.certificateNumber}`);
    // In real implementation, this would generate a PDF
  };

  const handleShareCertificate = (cert: Certificate) => {
    const shareText = `لقد أكملت دورة "${cert.courseTitle}" على منصة Smart Venom K! 🎉\nالرقم: ${cert.certificateNumber}\nالنسبة: ${cert.score}%`;
    const whatsappLink = `https://wa.me/?text=${encodeURIComponent(shareText)}`;
    window.open(whatsappLink, "_blank");
  };

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case "common":
        return "bg-gray-500/20 border-gray-500/50 text-gray-300";
      case "rare":
        return "bg-blue-500/20 border-blue-500/50 text-blue-300";
      case "epic":
        return "bg-purple-500/20 border-purple-500/50 text-purple-300";
      case "legendary":
        return "bg-yellow-500/20 border-yellow-500/50 text-yellow-300";
      default:
        return "bg-gray-500/20 border-gray-500/50 text-gray-300";
    }
  };

  return (
    <div className="min-h-screen bg-black text-white p-4 md:p-8 rtl" dir="rtl">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-cyan-400 to-magenta-500 bg-clip-text text-transparent">
          🏆 شهاداتي والإنجازات
        </h1>
        <p className="text-gray-400">
          عرض جميع الشهادات والإنجازات التي حصلت عليها
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <Card className="bg-gradient-to-br from-cyan-500/10 to-cyan-500/5 border-cyan-500/30 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">إجمالي الشهادات</p>
              <p className="text-3xl font-bold text-cyan-400">
                {certificates.length}
              </p>
            </div>
            <Award className="w-12 h-12 text-cyan-400/50" />
          </div>
        </Card>

        <Card className="bg-gradient-to-br from-magenta-500/10 to-magenta-500/5 border-magenta-500/30 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">الإنجازات</p>
              <p className="text-3xl font-bold text-magenta-400">
                {achievements.length}
              </p>
            </div>
            <Trophy className="w-12 h-12 text-magenta-400/50" />
          </div>
        </Card>

        <Card className="bg-gradient-to-br from-yellow-500/10 to-yellow-500/5 border-yellow-500/30 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">متوسط النسبة</p>
              <p className="text-3xl font-bold text-yellow-400">
                {Math.round(
                  certificates.reduce((sum, c) => sum + c.score, 0) /
                    certificates.length
                )}
                %
              </p>
            </div>
            <Star className="w-12 h-12 text-yellow-400/50" />
          </div>
        </Card>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="bg-gray-900 border border-cyan-500/30 w-full justify-start mb-6">
          <TabsTrigger
            value="certificates"
            className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400"
          >
            الشهادات ({certificates.length})
          </TabsTrigger>
          <TabsTrigger
            value="achievements"
            className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400"
          >
            الإنجازات ({achievements.length})
          </TabsTrigger>
        </TabsList>

        {/* Certificates Tab */}
        <TabsContent value="certificates" className="space-y-6">
          {certificates.length === 0 ? (
            <Card className="bg-gray-900 border-cyan-500/30 p-12 text-center">
              <p className="text-gray-400 text-lg mb-4">
                لم تحصل على أي شهادات حتى الآن
              </p>
              <Button
                onClick={() => navigate("/courses")}
                className="bg-gradient-to-r from-cyan-500 to-magenta-500 hover:from-cyan-600 hover:to-magenta-600"
              >
                ابدأ دورة الآن
              </Button>
            </Card>
          ) : (
            certificates.map((cert) => (
              <Card
                key={cert.id}
                className="bg-gradient-to-r from-gray-900 to-gray-800 border-cyan-500/30 p-6 hover:border-magenta-500/50 transition-all"
              >
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <Award className="w-6 h-6 text-cyan-400" />
                      <h3 className="text-xl font-bold text-white">
                        {cert.courseTitle}
                      </h3>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
                      <div>
                        <p className="text-gray-400 text-sm">المستوى</p>
                        <p className="text-cyan-400 font-bold">
                          {cert.level}
                        </p>
                      </div>
                      <div>
                        <p className="text-gray-400 text-sm">تاريخ الإكمال</p>
                        <p className="text-cyan-400 font-bold">
                          {new Date(cert.completionDate).toLocaleDateString(
                            "ar-EG"
                          )}
                        </p>
                      </div>
                      <div>
                        <p className="text-gray-400 text-sm">رقم الشهادة</p>
                        <p className="text-cyan-400 font-bold">
                          {cert.certificateNumber}
                        </p>
                      </div>
                      <div>
                        <p className="text-gray-400 text-sm">النسبة</p>
                        <p className="text-cyan-400 font-bold">{cert.score}%</p>
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      onClick={() => handleDownloadCertificate(cert)}
                      className="bg-cyan-500/20 border border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/30"
                    >
                      <Download className="w-4 h-4 ml-2" />
                      تحميل
                    </Button>
                    <Button
                      onClick={() => handleShareCertificate(cert)}
                      className="bg-magenta-500/20 border border-magenta-500/50 text-magenta-400 hover:bg-magenta-500/30"
                    >
                      <Share2 className="w-4 h-4 ml-2" />
                      مشاركة
                    </Button>
                  </div>
                </div>
              </Card>
            ))
          )}
        </TabsContent>

        {/* Achievements Tab */}
        <TabsContent value="achievements" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {achievements.map((achievement) => (
              <Card
                key={achievement.id}
                className={`border p-6 ${getRarityColor(achievement.rarity)}`}
              >
                <div className="text-center">
                  <div className="text-6xl mb-3">{achievement.icon}</div>
                  <h3 className="text-lg font-bold mb-2">
                    {achievement.title}
                  </h3>
                  <p className="text-sm opacity-80 mb-3">
                    {achievement.description}
                  </p>
                  <Badge className={`${getRarityColor(achievement.rarity)}`}>
                    {achievement.rarity === "common" && "عادي"}
                    {achievement.rarity === "rare" && "نادر"}
                    {achievement.rarity === "epic" && "ملحمي"}
                    {achievement.rarity === "legendary" && "أسطوري"}
                  </Badge>
                  <p className="text-xs opacity-60 mt-3">
                    تم الحصول عليه:{" "}
                    {new Date(achievement.unlockedDate).toLocaleDateString(
                      "ar-EG"
                    )}
                  </p>
                </div>
              </Card>
            ))}
          </div>

          {/* Locked Achievements */}
          <div className="mt-8">
            <h3 className="text-xl font-bold text-gray-400 mb-4">
              🔒 إنجازات مقفلة
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card className="bg-gray-900/50 border-gray-700/50 p-6 opacity-50">
                <div className="text-center">
                  <div className="text-6xl mb-3">🌟</div>
                  <h3 className="text-lg font-bold mb-2">الماستر</h3>
                  <p className="text-sm opacity-80 mb-3">
                    أكمل 10 دورات متقدمة
                  </p>
                  <Badge className="bg-gray-700/50 text-gray-400">
                    مقفل
                  </Badge>
                </div>
              </Card>

              <Card className="bg-gray-900/50 border-gray-700/50 p-6 opacity-50">
                <div className="text-center">
                  <div className="text-6xl mb-3">💎</div>
                  <h3 className="text-lg font-bold mb-2">الجوهرة النادرة</h3>
                  <p className="text-sm opacity-80 mb-3">
                    احصل على 100 في جميع الاختبارات
                  </p>
                  <Badge className="bg-gray-700/50 text-gray-400">
                    مقفل
                  </Badge>
                </div>
              </Card>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
