CREATE TABLE `achievements` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(100) NOT NULL,
	`description` text,
	`icon` varchar(255),
	`requirement` text,
	`xp_reward` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `achievements_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `certificates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`course_id` int NOT NULL,
	`certificate_number` varchar(50) NOT NULL,
	`issued_at` timestamp NOT NULL DEFAULT (now()),
	`expires_at` timestamp,
	`verification_url` varchar(255),
	CONSTRAINT `certificates_id` PRIMARY KEY(`id`),
	CONSTRAINT `certificates_certificate_number_unique` UNIQUE(`certificate_number`)
);
--> statement-breakpoint
CREATE TABLE `challenges` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(200) NOT NULL,
	`description` text,
	`type` enum('daily','weekly','monthly') NOT NULL,
	`difficulty` enum('easy','medium','hard') DEFAULT 'medium',
	`xp_reward` int DEFAULT 0,
	`start_date` timestamp DEFAULT (now()),
	`end_date` timestamp,
	`is_active` boolean DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `challenges_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `discounts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`code` varchar(50) NOT NULL,
	`discount_percent` int NOT NULL,
	`max_uses` int,
	`current_uses` int DEFAULT 0,
	`valid_from` timestamp DEFAULT (now()),
	`valid_until` timestamp,
	`is_active` boolean DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `discounts_id` PRIMARY KEY(`id`),
	CONSTRAINT `discounts_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `foreign_languages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(100) NOT NULL,
	`code` varchar(5) NOT NULL,
	`description` text,
	`icon` varchar(100),
	`order` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `foreign_languages_id` PRIMARY KEY(`id`),
	CONSTRAINT `foreign_languages_name_unique` UNIQUE(`name`),
	CONSTRAINT `foreign_languages_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `orders` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`course_id` int NOT NULL,
	`order_number` varchar(50) NOT NULL,
	`amount` decimal(10,2) NOT NULL,
	`status` enum('pending','paid','failed','refunded') DEFAULT 'pending',
	`payment_method` varchar(50) DEFAULT 'whatsapp',
	`whatsapp_message` text,
	`whatsapp_link` varchar(255),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`paid_at` timestamp,
	`expires_at` timestamp,
	CONSTRAINT `orders_id` PRIMARY KEY(`id`),
	CONSTRAINT `orders_order_number_unique` UNIQUE(`order_number`)
);
--> statement-breakpoint
CREATE TABLE `programming_languages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(100) NOT NULL,
	`description` text,
	`icon` varchar(100),
	`color` varchar(7),
	`order` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `programming_languages_id` PRIMARY KEY(`id`),
	CONSTRAINT `programming_languages_name_unique` UNIQUE(`name`)
);
--> statement-breakpoint
CREATE TABLE `user_achievements` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`achievement_id` int NOT NULL,
	`unlocked_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `user_achievements_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `user_challenge_progress` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`challenge_id` int NOT NULL,
	`progress` int DEFAULT 0,
	`is_completed` boolean DEFAULT false,
	`completed_at` timestamp,
	`started_at` timestamp DEFAULT (now()),
	CONSTRAINT `user_challenge_progress_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `user_enrollments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`course_id` int NOT NULL,
	`enrolled_at` timestamp NOT NULL DEFAULT (now()),
	`completed_at` timestamp,
	`progress` int DEFAULT 0,
	CONSTRAINT `user_enrollments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `courses` MODIFY COLUMN `level` enum('beginner','intermediate','advanced','professional') NOT NULL;--> statement-breakpoint
ALTER TABLE `courses` ADD `category` enum('programming','english','french') NOT NULL;--> statement-breakpoint
ALTER TABLE `courses` ADD `programming_language_id` int;--> statement-breakpoint
ALTER TABLE `courses` ADD `foreign_language_id` int;--> statement-breakpoint
ALTER TABLE `courses` ADD `price` decimal(10,2) DEFAULT '369.00';--> statement-breakpoint
ALTER TABLE `courses` ADD `thumbnail` varchar(255);--> statement-breakpoint
ALTER TABLE `courses` ADD `is_active` boolean DEFAULT true;--> statement-breakpoint
ALTER TABLE `lessons` ADD `video_url` varchar(255);