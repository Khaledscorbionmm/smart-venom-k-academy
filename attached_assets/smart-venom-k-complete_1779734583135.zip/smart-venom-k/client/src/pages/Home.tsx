import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { MessageCircle, Code2, Zap, Users, Award, BookOpen } from "lucide-react";

import { useLocation } from "wouter";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  
  // WhatsApp number: 01034009418 (Egypt format)
  // Convert to international format for WhatsApp API: +201034009418
  const whatsappNumber = "201034009418";
  const whatsappUrl = `https://wa.me/${whatsappNumber}?text=مرحبا%20بي%20في%20Smart%20Venom%20K`;

  return (
    <div className="min-h-screen bg-background text-foreground overflow-hidden">
      {/* Navigation */}
      <nav className="fixed top-0 right-0 left-0 z-50 glass-card border-b border-border">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-neon-cyan to-neon-magenta flex items-center justify-center">
              <Code2 className="w-6 h-6 text-background" />
            </div>
            <span className="text-xl font-bold neon-text">Smart Venom K</span>
          </div>
          
          <div className="flex items-center gap-4">
            {isAuthenticated ? (
              <>
                <Button
                  onClick={() => navigate("/courses")}
                  className="btn-neon"
                >
                  الدورات
                </Button>
                <Button
                  onClick={() => navigate("/store")}
                  className="btn-neon"
                >
                  🛍️ المتجر
                </Button>
                <div className="text-sm text-text-secondary">
                  مرحبا {user?.name}
                </div>
              </>
            ) : (
              <>
                <a href="/auth">
                  <Button className="btn-neon">
                    دخول
                  </Button>
                </a>
              </>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 right-10 w-96 h-96 bg-neon-cyan rounded-full blur-3xl"></div>
          <div className="absolute bottom-20 left-10 w-96 h-96 bg-neon-magenta rounded-full blur-3xl"></div>
        </div>
        
        <div className="container mx-auto relative z-10">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-7xl font-bold mb-6 animate-pulse">
              <span className="bracket-left">تعلم البرمجة</span>
              <br />
              <span className="neon-text bracket-right">بطريقة جديدة</span>
            </h1>
            
            <p className="text-xl md:text-2xl text-text-secondary mb-8 leading-relaxed">
              منصة تعليمية متقدمة لتعليم لغة Python بالعربية مع نظام تحديات وتصنيفات عالمية
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <a href="/auth">
                <Button className="btn-neon text-lg px-8 py-6 w-full sm:w-auto">
                  ابدأ الآن
                </Button>
              </a>
              <a href={whatsappUrl} target="_blank" rel="noopener noreferrer" title="WhatsApp: 01034009418">
                <Button className="px-8 py-6 w-full sm:w-auto border-2 border-neon-cyan text-neon-cyan hover:bg-neon-cyan/10 transition-all">
                  <MessageCircle className="w-5 h-5 ml-2" />
                  تواصل معنا
                </Button>
              </a>
            </div>
            
            {/* Code Example Display */}
            <div className="glass-card p-6 max-w-2xl mx-auto">
              <div className="text-left text-sm font-mono text-neon-cyan">
                <div className="text-error-code mb-2">{'> SMART_VENOM_K_INITIALIZED'}</div>
                <div>
                  <span className="text-neon-green">def</span>
                  <span className="text-text-primary"> learn_python():</span>
                </div>
                <div className="ml-4">
                  <span className="text-neon-magenta">return</span>
                  <span className="text-text-primary"> Success()</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 bg-bg-secondary/20">
        <div className="container mx-auto">
          <h2 className="text-4xl font-bold text-center mb-16 neon-text">
            المميزات الرئيسية
          </h2>
          
          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                icon: BookOpen,
                title: "دورات شاملة",
                description: "7 دورات برمجية + 3 لغات إنسانية مع شهادات معتمدة"
              },
              {
                icon: Zap,
                title: "نظام التحديات",
                description: "اكسب نقاط XP وحافظ على سلسلة تعليمك اليومية"
              },
              {
                icon: Award,
                title: "تصنيفات عالمية",
                description: "تنافس مع متعلمين آخرين واحصل على شارات"
              },
              {
                icon: Code2,
                title: "محرر كود تفاعلي",
                description: "اكتب وشغل الكود مباشرة داخل المنصة"
              },
              {
                icon: Users,
                title: "مجتمع نشط",
                description: "تواصل مع متعلمين آخرين وشارك تجاربك"
              },
              {
                icon: MessageCircle,
                title: "دعم مباشر",
                description: "احصل على الدعم الفوري عبر WhatsApp"
              }
            ].map((feature, idx) => (
              <Card key={idx} className="glass-card p-6 border border-border hover:border-neon-cyan/50 transition-all">
                <feature.icon className="w-12 h-12 mb-4 text-neon-cyan" />
                <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                <p className="text-text-secondary">{feature.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Course Preview Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <h2 className="text-4xl font-bold text-center mb-16 neon-text">
            الدورات المتاحة
          </h2>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { title: "مقدمة إلى Python", level: "مبتدئ", lessons: 10 },
              { title: "المتغيرات والبيانات", level: "مبتدئ", lessons: 8 },
              { title: "البرمجة كائنية التوجه", level: "متقدم", lessons: 12 },
              { title: "معالجة الملفات", level: "متوسط", lessons: 7 },
              { title: "قواعد البيانات", level: "متقدم", lessons: 15 },
              { title: "تطوير الويب", level: "متقدم", lessons: 20 }
            ].map((course, idx) => (
              <Card key={idx} className="glass-card p-6 border border-border hover:border-neon-magenta/50 transition-all cursor-pointer group">
                <div className="mb-4">
                  <span className="inline-block px-3 py-1 rounded text-sm font-mono text-neon-green bg-neon-green/10">
                    {course.level}
                  </span>
                </div>
                <h3 className="text-xl font-bold mb-2 group-hover:text-neon-cyan transition-colors">
                  {course.title}
                </h3>
                <p className="text-text-secondary mb-4">
                  {course.lessons} درس تعليمي شامل
                </p>
                <div className="w-full h-1 bg-bg-tertiary rounded-full overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-neon-cyan to-neon-magenta w-0 group-hover:w-1/3 transition-all duration-500"></div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-bg-secondary/30">
        <div className="container mx-auto text-center">
          <h2 className="text-4xl font-bold mb-6">
            هل أنت مستعد للبدء؟
          </h2>
          <p className="text-xl text-text-secondary mb-8 max-w-2xl mx-auto">
            انضم إلى آلاف المتعلمين الذين يطورون مهاراتهم البرمجية معنا
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a href="/auth">
              <Button className="btn-neon text-lg px-8 py-6 w-full sm:w-auto">
                سجل الآن
              </Button>
            </a>
            <a href={whatsappUrl} target="_blank" rel="noopener noreferrer" title="WhatsApp: 01034009418">
              <Button className="px-8 py-6 w-full sm:w-auto border-2 border-neon-cyan text-neon-cyan hover:bg-neon-cyan/10 transition-all">
                <MessageCircle className="w-5 h-5 ml-2" />
                تواصل معنا
              </Button>
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8 px-4">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-bold mb-4 text-neon-cyan">عن المنصة</h4>
              <p className="text-text-secondary text-sm">
                منصة تعليمية متخصصة في تعليم البرمجة بالعربية
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-4 text-neon-cyan">الدورات</h4>
              <ul className="text-text-secondary text-sm space-y-2">
                <li><a href="#" className="hover:text-neon-cyan transition">Python</a></li>
                <li><a href="#" className="hover:text-neon-cyan transition">الويب</a></li>
                <li><a href="#" className="hover:text-neon-cyan transition">قواعد البيانات</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4 text-neon-cyan">المساعدة</h4>
              <ul className="text-text-secondary text-sm space-y-2">
                <li><a href="#" className="hover:text-neon-cyan transition">الأسئلة الشائعة</a></li>
                <li><a href="#" className="hover:text-neon-cyan transition">الدعم</a></li>
                <li><a href="#" className="hover:text-neon-cyan transition">الشروط والأحكام</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4 text-neon-cyan">تواصل</h4>
            <a href={whatsappUrl} target="_blank" rel="noopener noreferrer" className="text-text-secondary hover:text-neon-cyan transition font-bold">
              WhatsApp: 01034009418
            </a>
            </div>
          </div>
          
          <div className="border-t border-border pt-8 text-center text-text-secondary text-sm">
            <p>© 2026 Smart Venom K. جميع الحقوق محفوظة.</p>
          </div>
        </div>
      </footer>

      {/* WhatsApp Floating Button */}
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 left-6 w-14 h-14 bg-gradient-to-br from-neon-green to-neon-cyan rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition-transform z-40"
      >
        <MessageCircle className="w-7 h-7 text-background" />
      </a>
    </div>
  );
}
