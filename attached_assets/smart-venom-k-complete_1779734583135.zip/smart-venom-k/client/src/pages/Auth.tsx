import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";
import { Code2, Loader2 } from "lucide-react";

type AuthMode = "login" | "register";

export default function Auth() {
  const { isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const [mode, setMode] = useState<AuthMode>("login");
  const [isLoading, setIsLoading] = useState(false);
  
  const [loginForm, setLoginForm] = useState({ email: "", password: "" });
  const [registerForm, setRegisterForm] = useState({ email: "", password: "", promoCode: "" });

  if (isAuthenticated) {
    navigate("/courses");
    return null;
  }

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      // Mock login - in production, use tRPC mutation
      if (loginForm.email && loginForm.password) {
        toast.success("تم تسجيل الدخول بنجاح");
        navigate("/courses");
      } else {
        toast.error("يرجى ملء جميع الحقول");
      }
    } catch (error) {
      toast.error("حدث خطأ أثناء تسجيل الدخول");
    } finally {
      setIsLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      if (!registerForm.email || !registerForm.password || !registerForm.promoCode) {
        toast.error("يرجى ملء جميع الحقول");
        return;
      }
      
      // Validate promo code
      if (registerForm.promoCode.length < 3) {
        toast.error("رمز الترويج غير صحيح");
        return;
      }
      
      toast.success("تم إنشاء الحساب بنجاح");
      setMode("login");
      setRegisterForm({ email: "", password: "", promoCode: "" });
    } catch (error) {
      toast.error("حدث خطأ أثناء إنشاء الحساب");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 mb-4">
            <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-neon-cyan to-neon-magenta flex items-center justify-center">
              <Code2 className="w-8 h-8 text-background" />
            </div>
            <span className="text-2xl font-bold neon-text">Smart Venom K</span>
          </div>
          <p className="text-text-secondary">منصة تعليم البرمجة بالعربية</p>
        </div>

        {/* Auth Card */}
        <Card className="glass-card p-8 border border-border">
          {/* Tabs */}
          <div className="flex gap-4 mb-8 border-b border-border pb-4">
            <button
              onClick={() => setMode("login")}
              className={`flex-1 pb-2 transition-colors ${
                mode === "login"
                  ? "text-neon-cyan border-b-2 border-neon-cyan"
                  : "text-text-secondary hover:text-text-primary"
              }`}
            >
              دخول
            </button>
            <button
              onClick={() => setMode("register")}
              className={`flex-1 pb-2 transition-colors ${
                mode === "register"
                  ? "text-neon-cyan border-b-2 border-neon-cyan"
                  : "text-text-secondary hover:text-text-primary"
              }`}
            >
              إنشاء حساب
            </button>
          </div>

          {/* Login Form */}
          {mode === "login" && (
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">البريد الإلكتروني</label>
                <Input
                  type="email"
                  placeholder="your@email.com"
                  value={loginForm.email}
                  onChange={(e) => setLoginForm({ ...loginForm, email: e.target.value })}
                  className="w-full bg-bg-secondary/50 border border-border rounded px-4 py-2 text-text-primary placeholder-text-secondary/50 focus:border-neon-cyan focus:outline-none transition-colors"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">كلمة المرور</label>
                <Input
                  type="password"
                  placeholder="••••••••"
                  value={loginForm.password}
                  onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
                  className="w-full bg-bg-secondary/50 border border-border rounded px-4 py-2 text-text-primary placeholder-text-secondary/50 focus:border-neon-cyan focus:outline-none transition-colors"
                />
              </div>
              
              <Button
                type="submit"
                disabled={isLoading}
                className="btn-neon w-full"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 ml-2 animate-spin" />
                    جاري...
                  </>
                ) : (
                  "دخول"
                )}
              </Button>
            </form>
          )}

          {/* Register Form */}
          {mode === "register" && (
            <form onSubmit={handleRegister} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">البريد الإلكتروني</label>
                <Input
                  type="email"
                  placeholder="your@email.com"
                  value={registerForm.email}
                  onChange={(e) => setRegisterForm({ ...registerForm, email: e.target.value })}
                  className="w-full bg-bg-secondary/50 border border-border rounded px-4 py-2 text-text-primary placeholder-text-secondary/50 focus:border-neon-cyan focus:outline-none transition-colors"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">كلمة المرور</label>
                <Input
                  type="password"
                  placeholder="••••••••"
                  value={registerForm.password}
                  onChange={(e) => setRegisterForm({ ...registerForm, password: e.target.value })}
                  className="w-full bg-bg-secondary/50 border border-border rounded px-4 py-2 text-text-primary placeholder-text-secondary/50 focus:border-neon-cyan focus:outline-none transition-colors"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">رمز الترويج</label>
                <Input
                  type="text"
                  placeholder="أدخل رمز الترويج"
                  value={registerForm.promoCode}
                  onChange={(e) => setRegisterForm({ ...registerForm, promoCode: e.target.value.toUpperCase() })}
                  className="w-full bg-bg-secondary/50 border border-border rounded px-4 py-2 text-text-primary placeholder-text-secondary/50 focus:border-neon-cyan focus:outline-none transition-colors font-mono"
                />
                <p className="text-xs text-text-secondary mt-2">
                  يمكنك الحصول على رمز ترويج من خلال التواصل معنا عبر WhatsApp
                </p>
              </div>
              
              <Button
                type="submit"
                disabled={isLoading}
                className="btn-neon w-full"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 ml-2 animate-spin" />
                    جاري...
                  </>
                ) : (
                  "إنشاء حساب"
                )}
              </Button>
            </form>
          )}

          {/* Footer */}
          <div className="mt-6 pt-6 border-t border-border text-center text-sm text-text-secondary">
            <p>
              {mode === "login" ? "ليس لديك حساب؟" : "لديك حساب بالفعل؟"}
              <button
                onClick={() => setMode(mode === "login" ? "register" : "login")}
                className="text-neon-cyan hover:text-neon-magenta transition-colors ml-2 font-bold"
              >
                {mode === "login" ? "إنشاء حساب" : "دخول"}
              </button>
            </p>
          </div>
        </Card>

        {/* Info Box */}
        <Card className="glass-card p-4 border border-border mt-6">
          <p className="text-sm text-text-secondary">
            <span className="text-neon-cyan font-bold">ملاحظة:</span> هذه المنصة تتطلب رمز ترويج للتسجيل. يمكنك الحصول على رمز من خلال التواصل معنا.
          </p>
        </Card>
      </div>
    </div>
  );
}
