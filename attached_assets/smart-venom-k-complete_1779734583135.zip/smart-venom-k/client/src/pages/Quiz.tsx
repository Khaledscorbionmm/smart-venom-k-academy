import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useState } from "react";
import { useLocation, useRoute } from "wouter";
import { Loader2, CheckCircle, XCircle, RotateCcw } from "lucide-react";
import { toast } from "sonner";

interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
}

// Sample quiz questions
const QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 1,
    question: "ما هو الناتج من تنفيذ الكود التالي: print(2 + 3 * 4)?",
    options: ["20", "14", "18", "9"],
    correctAnswer: 1,
  },
  {
    id: 2,
    question: "أي من الخيارات التالية يستخدم لإنشاء قائمة في Python?",
    options: ["()", "{}", "[]", "<>"],
    correctAnswer: 2,
  },
  {
    id: 3,
    question: "ما هي الدالة المستخدمة لحساب عدد العناصر في قائمة?",
    options: ["size()", "length()", "len()", "count()"],
    correctAnswer: 2,
  },
  {
    id: 4,
    question: "ما هو نوع البيانات للقيمة 3.14 في Python?",
    options: ["int", "float", "string", "boolean"],
    correctAnswer: 1,
  },
  {
    id: 5,
    question: "أي من الحلقات التالية تكرر العملية 5 مرات?",
    options: ["for i in range(6):", "for i in range(5):", "for i in 5:", "for i = 1 to 5:"],
    correctAnswer: 1,
  },
];

export default function Quiz() {
  const { isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const [, params] = useRoute("/quiz/:id");
  
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<(number | null)[]>(
    new Array(QUIZ_QUESTIONS.length).fill(null)
  );
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [score, setScore] = useState(0);

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-xl">يجب عليك تسجيل الدخول أولاً</p>
      </div>
    );
  }

  const handleSelectAnswer = (optionIndex: number) => {
    if (!quizSubmitted) {
      const newAnswers = [...selectedAnswers];
      newAnswers[currentQuestion] = optionIndex;
      setSelectedAnswers(newAnswers);
    }
  };

  const handleSubmitQuiz = () => {
    let correctCount = 0;
    selectedAnswers.forEach((answer, index) => {
      if (answer === QUIZ_QUESTIONS[index].correctAnswer) {
        correctCount++;
      }
    });
    
    const finalScore = Math.round((correctCount / QUIZ_QUESTIONS.length) * 100);
    setScore(finalScore);
    setQuizSubmitted(true);
    
    if (finalScore >= 70) {
      toast.success(`رائع! حصلت على ${finalScore}%`);
    } else {
      toast.error(`يمكنك المحاولة مرة أخرى. حصلت على ${finalScore}%`);
    }
  };

  const handleReset = () => {
    setCurrentQuestion(0);
    setSelectedAnswers(new Array(QUIZ_QUESTIONS.length).fill(null));
    setQuizSubmitted(false);
    setScore(0);
  };

  const question = QUIZ_QUESTIONS[currentQuestion];
  const isAnswered = selectedAnswers[currentQuestion] !== null;
  const isCorrect = selectedAnswers[currentQuestion] === question.correctAnswer;

  return (
    <div className="min-h-screen bg-background text-foreground pt-20 pb-12 px-4">
      <div className="container mx-auto max-w-2xl">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold neon-text mb-2">اختبر معلوماتك</h1>
          <p className="text-text-secondary">أجب على جميع الأسئلة لاختبار فهمك</p>
        </div>

        {!quizSubmitted ? (
          <>
            {/* Progress Bar */}
            <Card className="glass-card p-4 border border-border mb-6">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm text-text-secondary">
                  السؤال {currentQuestion + 1} من {QUIZ_QUESTIONS.length}
                </span>
                <span className="text-sm text-neon-cyan font-bold">
                  {Math.round(((currentQuestion + 1) / QUIZ_QUESTIONS.length) * 100)}%
                </span>
              </div>
              <div className="w-full h-2 bg-bg-secondary rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-neon-cyan to-neon-magenta transition-all duration-300"
                  style={{
                    width: `${((currentQuestion + 1) / QUIZ_QUESTIONS.length) * 100}%`,
                  }}
                ></div>
              </div>
            </Card>

            {/* Question Card */}
            <Card className="glass-card p-8 border border-border mb-6">
              <h2 className="text-2xl font-bold mb-6 text-neon-cyan">{question.question}</h2>

              {/* Options */}
              <div className="space-y-3 mb-8">
                {question.options.map((option, index) => (
                  <button
                    key={index}
                    onClick={() => handleSelectAnswer(index)}
                    disabled={quizSubmitted}
                    className={`w-full p-4 rounded border-2 transition-all text-right ${
                      selectedAnswers[currentQuestion] === index
                        ? "border-neon-cyan bg-neon-cyan/10"
                        : "border-border hover:border-neon-cyan/50"
                    } ${quizSubmitted && "cursor-not-allowed"}`}
                  >
                    <div className="flex items-center justify-between">
                      <span>{option}</span>
                      <div className="w-5 h-5 rounded border-2 border-current flex items-center justify-center">
                        {selectedAnswers[currentQuestion] === index && (
                          <div className="w-3 h-3 bg-current rounded-full"></div>
                        )}
                      </div>
                    </div>
                  </button>
                ))}
              </div>

              {/* Navigation Buttons */}
              <div className="flex gap-4">
                <Button
                  onClick={() => setCurrentQuestion(Math.max(0, currentQuestion - 1))}
                  disabled={currentQuestion === 0}
                  className="flex-1 border border-border text-text-secondary hover:text-text-primary"
                >
                  السابق
                </Button>
                
                {currentQuestion < QUIZ_QUESTIONS.length - 1 ? (
                  <Button
                    onClick={() => setCurrentQuestion(currentQuestion + 1)}
                    className="flex-1 btn-neon"
                  >
                    التالي
                  </Button>
                ) : (
                  <Button
                    onClick={handleSubmitQuiz}
                    disabled={selectedAnswers.some((a) => a === null)}
                    className="flex-1 btn-neon"
                  >
                    إرسال الإجابات
                  </Button>
                )}
              </div>
            </Card>
          </>
        ) : (
          <>
            {/* Results */}
            <Card className="glass-card p-8 border border-border mb-6 text-center">
              <div className="mb-6">
                {score >= 70 ? (
                  <CheckCircle className="w-16 h-16 mx-auto text-neon-green mb-4" />
                ) : (
                  <XCircle className="w-16 h-16 mx-auto text-neon-magenta mb-4" />
                )}
              </div>
              
              <h2 className="text-3xl font-bold mb-2">
                {score >= 70 ? "تهانينا!" : "حاول مرة أخرى"}
              </h2>
              
              <p className="text-5xl font-bold neon-text mb-4">{score}%</p>
              
              <p className="text-text-secondary mb-6">
                {score >= 70
                  ? "لقد أتممت الاختبار بنجاح وحصلت على نقاط XP!"
                  : "يمكنك المحاولة مرة أخرى لتحسين درجتك"}
              </p>

              {/* Answer Review */}
              <div className="mt-8 space-y-4 text-right">
                <h3 className="text-xl font-bold text-neon-cyan mb-4">مراجعة الإجابات</h3>
                {QUIZ_QUESTIONS.map((q, idx) => (
                  <div
                    key={idx}
                    className={`p-4 rounded border-l-4 ${
                      selectedAnswers[idx] === q.correctAnswer
                        ? "border-l-neon-green bg-neon-green/5"
                        : "border-l-neon-magenta bg-neon-magenta/5"
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-2">
                      {selectedAnswers[idx] === q.correctAnswer ? (
                        <CheckCircle className="w-5 h-5 text-neon-green" />
                      ) : (
                        <XCircle className="w-5 h-5 text-neon-magenta" />
                      )}
                      <span className="font-bold">{q.question}</span>
                    </div>
                    <p className="text-sm text-text-secondary">
                      إجابتك: {q.options[selectedAnswers[idx] || 0]}
                    </p>
                    {selectedAnswers[idx] !== q.correctAnswer && (
                      <p className="text-sm text-neon-green">
                        الإجابة الصحيحة: {q.options[q.correctAnswer]}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </Card>

            {/* Action Buttons */}
            <div className="flex gap-4">
              <Button
                onClick={handleReset}
                className="flex-1 flex items-center justify-center gap-2 btn-neon"
              >
                <RotateCcw className="w-4 h-4" />
                حاول مرة أخرى
              </Button>
              <Button
                onClick={() => navigate("/courses")}
                className="flex-1 border border-border text-text-secondary hover:text-text-primary"
              >
                العودة للدورات
              </Button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
