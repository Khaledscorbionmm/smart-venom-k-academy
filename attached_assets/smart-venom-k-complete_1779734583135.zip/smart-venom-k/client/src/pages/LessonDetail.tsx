import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2, ChevronRight, CheckCircle, Award } from "lucide-react";
import { useLocation, useRoute } from "wouter";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { toast } from "sonner";

export default function LessonDetail() {
  const { isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const [, params] = useRoute("/lesson/:id");
  const [completed, setCompleted] = useState(false);
  
  const lessonId = params?.id ? parseInt(params.id) : 0;
  
  const { data: lesson, isLoading } = trpc.lessons.getById.useQuery(
    { id: lessonId },
    { enabled: isAuthenticated && lessonId > 0 }
  );
  
  const markCompleteMutation = trpc.lessons.markComplete.useMutation({
    onSuccess: () => {
      setCompleted(true);
      toast.success("تم إكمال الدرس بنجاح! حصلت على 100 نقطة XP");
    },
    onError: () => {
      toast.error("حدث خطأ أثناء إكمال الدرس");
    },
  });
  
  const handleMarkComplete = () => {
    markCompleteMutation.mutate({ lessonId });
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-xl">يجب عليك تسجيل الدخول أولاً</p>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-neon-cyan" />
      </div>
    );
  }

  if (!lesson) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-xl text-text-secondary">لم يتم العثور على الدرس</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="glass-card border-b border-border">
        <div className="container mx-auto px-4 py-6">
          <button
            onClick={() => navigate("/courses")}
            className="flex items-center gap-2 text-neon-cyan hover:text-neon-magenta transition-colors mb-4"
          >
            <ChevronRight className="w-5 h-5" />
            العودة
          </button>
          <h1 className="text-4xl font-bold neon-text">{lesson.title}</h1>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Lesson Content */}
            <Card className="glass-card p-8 border border-border">
              <h2 className="text-2xl font-bold mb-4 text-neon-cyan">محتوى الدرس</h2>
              <div className="prose prose-invert max-w-none text-text-secondary leading-relaxed">
                {lesson.content ? (
                  <p>{lesson.content}</p>
                ) : (
                  <p>لا يوجد محتوى متاح لهذا الدرس حالياً</p>
                )}
              </div>
            </Card>

            {/* Code Example */}
            {lesson.codeExample && (
              <Card className="glass-card p-8 border border-border">
                <h2 className="text-2xl font-bold mb-4 text-neon-cyan">مثال برمجي</h2>
                <div className="bg-bg-primary rounded p-4 border border-border overflow-x-auto">
                  <pre className="text-sm font-mono text-neon-green">
                    <code>{lesson.codeExample}</code>
                  </pre>
                </div>
              </Card>
            )}

              {/* Quiz Section */}
            <Card className="glass-card p-8 border border-border">
              <h2 className="text-2xl font-bold mb-6 text-neon-cyan">اختبر معلوماتك</h2>
              <p className="text-text-secondary mb-6">
                الاختبار يتضمن 5 أسئلة لاختبار فهمك للدرس. النجاح يتطلب 70% أو أكثر.
              </p>
              <Button
                onClick={() => navigate(`/quiz/${lesson.id}`)}
                className="btn-neon w-full"
              >
                ابدأ الاختبار
              </Button>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* XP Reward */}
            <Card className="glass-card p-6 border border-border">
              <div className="flex items-center gap-3 mb-4">
                <Award className="w-6 h-6 text-neon-green" />
                <h3 className="font-bold">مكافأة الدرس</h3>
              </div>
              <p className="text-3xl font-bold text-neon-cyan mb-2">
                {lesson.xpReward || 100}
              </p>
              <p className="text-sm text-text-secondary">نقطة XP</p>
            </Card>

            {/* Completion Status */}
            <Card className="glass-card p-6 border border-border">
              <div className="flex items-center gap-3 mb-4">
                <CheckCircle className="w-6 h-6 text-neon-green" />
                <h3 className="font-bold">حالة الإكمال</h3>
              </div>
              <p className="text-sm text-text-secondary mb-4">
                {completed ? "تم إكمال هذا الدرس" : "لم يتم إكمال هذا الدرس بعد"}
              </p>
              {!completed && (
                <Button
                  onClick={handleMarkComplete}
                  disabled={markCompleteMutation.isPending}
                  className="btn-neon w-full"
                >
                  {markCompleteMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 ml-2 animate-spin" />
                      جاري...
                    </>
                  ) : (
                    "إكمال الدرس"
                  )}
                </Button>
              )}
            </Card>

            {/* Lesson Info */}
            <Card className="glass-card p-6 border border-border">
              <h3 className="font-bold mb-4">معلومات الدرس</h3>
              <div className="space-y-3 text-sm">
                <div>
                  <p className="text-text-secondary">معرّف الدرس</p>
                  <p className="font-mono text-neon-cyan">{lesson.id}</p>
                </div>
                <div>
                  <p className="text-text-secondary">تاريخ الإنشاء</p>
                  <p>{new Date(lesson.createdAt).toLocaleDateString("ar-EG")}</p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
