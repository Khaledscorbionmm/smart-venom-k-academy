import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { BarChart3, Users, BookOpen, Gift, LogOut, Menu, X } from "lucide-react";
import { toast } from "sonner";

type AdminTab = "dashboard" | "users" | "courses" | "promo-codes";

export default function AdminDashboard() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState<AdminTab>("dashboard");
  const [sidebarOpen, setSidebarOpen] = useState(true);
  
  const logoutMutation = trpc.auth.logout.useMutation({
    onSuccess: () => {
      navigate("/");
    },
  });

  const { data: stats } = trpc.admin.getStats.useQuery(undefined, {
    enabled: isAuthenticated && user?.role === "admin",
  });

  const { data: promoCodes } = trpc.admin.getPromoCodes.useQuery(undefined, {
    enabled: isAuthenticated && user?.role === "admin" && activeTab === "promo-codes",
  });

  if (!isAuthenticated || user?.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-xl mb-4 text-text-secondary">لا توجد صلاحيات كافية</p>
          <Button className="btn-neon" onClick={() => navigate("/")}>
            العودة للرئيسية
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground flex">
      {/* Sidebar */}
      <div className={`${sidebarOpen ? "w-64" : "w-0"} glass-card border-r border-border transition-all duration-300 overflow-hidden flex flex-col`}>
        <div className="p-6 border-b border-border">
          <h2 className="text-2xl font-bold neon-text">لوحة التحكم</h2>
          <p className="text-sm text-text-secondary mt-2">مدير النظام</p>
        </div>

        <nav className="flex-1 p-4 space-y-2">
          {[
            { id: "dashboard" as const, label: "لوحة المعلومات", icon: BarChart3 },
            { id: "users" as const, label: "المستخدمون", icon: Users },
            { id: "courses" as const, label: "الدورات", icon: BookOpen },
            { id: "promo-codes" as const, label: "رموز الترويج", icon: Gift },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded transition-all ${
                activeTab === item.id
                  ? "bg-neon-cyan/20 text-neon-cyan border border-neon-cyan"
                  : "text-text-secondary hover:bg-bg-secondary/50"
              }`}
            >
              <item.icon className="w-5 h-5" />
              <span>{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-border">
          <Button
            onClick={() => logoutMutation.mutate()}
            className="w-full flex items-center justify-center gap-2 px-4 py-2 border border-border text-text-secondary hover:text-neon-magenta transition-colors"
          >
            <LogOut className="w-4 h-4" />
            تسجيل الخروج
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        {/* Top Bar */}
        <div className="glass-card border-b border-border sticky top-0 z-40">
          <div className="px-6 py-4 flex justify-between items-center">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="lg:hidden text-neon-cyan"
            >
              {sidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
            <h1 className="text-2xl font-bold">
              {activeTab === "dashboard" && "لوحة المعلومات"}
              {activeTab === "users" && "إدارة المستخدمين"}
              {activeTab === "courses" && "إدارة الدورات"}
              {activeTab === "promo-codes" && "رموز الترويج"}
            </h1>
            <div className="text-right">
              <p className="text-sm text-text-secondary">مرحبا {user?.name}</p>
            </div>
          </div>
        </div>

        {/* Content Area */}
        <div className="p-6">
          {activeTab === "dashboard" && (
            <div className="space-y-6">
              <div className="grid md:grid-cols-3 gap-6">
                {[
                  { label: "إجمالي المستخدمين", value: stats?.totalUsers || 0, icon: Users, color: "text-neon-cyan" },
                  { label: "إجمالي الدورات", value: stats?.totalCourses || 0, icon: BookOpen, color: "text-neon-green" },
                  { label: "إجمالي الدروس", value: stats?.totalLessons || 0, icon: BarChart3, color: "text-neon-magenta" },
                ].map((stat, idx) => (
                  <Card key={idx} className="glass-card p-6 border border-border">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-text-secondary text-sm">{stat.label}</p>
                        <p className="text-3xl font-bold mt-2">{stat.value}</p>
                      </div>
                      <stat.icon className={`w-12 h-12 ${stat.color} opacity-50`} />
                    </div>
                  </Card>
                ))}
              </div>

              <Card className="glass-card p-6 border border-border">
                <h3 className="text-xl font-bold mb-4 text-neon-cyan">الإحصائيات العامة</h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-center p-3 bg-bg-secondary/50 rounded">
                    <span>معدل تفعيل المستخدمين</span>
                    <span className="font-bold text-neon-green">85%</span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-bg-secondary/50 rounded">
                    <span>متوسط إكمال الدروس</span>
                    <span className="font-bold text-neon-cyan">72%</span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-bg-secondary/50 rounded">
                    <span>عدد الدروس المكتملة اليوم</span>
                    <span className="font-bold text-neon-magenta">24</span>
                  </div>
                </div>
              </Card>
            </div>
          )}

          {activeTab === "users" && (
            <Card className="glass-card p-6 border border-border">
              <h3 className="text-xl font-bold mb-4 text-neon-cyan">قائمة المستخدمين</h3>
              <p className="text-text-secondary">سيتم إضافة إدارة المستخدمين قريباً</p>
            </Card>
          )}

          {activeTab === "courses" && (
            <Card className="glass-card p-6 border border-border">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-bold text-neon-cyan">إدارة الدورات</h3>
                <Button className="btn-neon text-sm">+ إضافة دورة جديدة</Button>
              </div>
              <p className="text-text-secondary">سيتم إضافة إدارة الدورات قريباً</p>
            </Card>
          )}

          {activeTab === "promo-codes" && (
            <div className="space-y-6">
              <Card className="glass-card p-6 border border-border">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-xl font-bold text-neon-cyan">رموز الترويج</h3>
                  <Button className="btn-neon text-sm">+ إنشاء رمز جديد</Button>
                </div>
                
                {promoCodes && promoCodes.length > 0 ? (
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-border">
                          <th className="text-right p-3 text-text-secondary">الرمز</th>
                          <th className="text-right p-3 text-text-secondary">الحالة</th>
                          <th className="text-right p-3 text-text-secondary">تاريخ الإنشاء</th>
                        </tr>
                      </thead>
                      <tbody>
                        {promoCodes.map((code) => (
                          <tr key={code.id} className="border-b border-border hover:bg-bg-secondary/30">
                            <td className="p-3 font-mono text-neon-cyan">{code.code}</td>
                            <td className="p-3">
                              <span className={`px-3 py-1 rounded text-sm ${
                                code.isUsed
                                  ? "bg-red-500/20 text-red-400"
                                  : "bg-green-500/20 text-green-400"
                              }`}>
                                {code.isUsed ? "مستخدم" : "متاح"}
                              </span>
                            </td>
                            <td className="p-3 text-text-secondary">
                              {new Date(code.createdAt).toLocaleDateString("ar-EG")}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <p className="text-text-secondary">لا توجد رموز ترويج</p>
                )}
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
