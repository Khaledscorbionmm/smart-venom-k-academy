import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Zap, Target, Flame, Clock } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

interface Challenge {
  id: number;
  title: string;
  description: string;
  difficulty: "easy" | "medium" | "hard";
  reward: number;
  progress: number;
  target: number;
  icon: string;
  status: "active" | "completed" | "locked";
}

interface Streak {
  current: number;
  best: number;
  lastUpdated: string;
}

export default function Challenges() {
  const [activeTab, setActiveTab] = useState("active");
  const [streak, setStreak] = useState<Streak>({
    current: 7,
    best: 15,
    lastUpdated: new Date().toLocaleDateString("ar-EG"),
  });

  const challenges: Challenge[] = [
    {
      id: 1,
      title: "المتعلم اليومي",
      description: "أكمل درس واحد يومياً",
      difficulty: "easy",
      reward: 50,
      progress: 7,
      target: 30,
      icon: "📚",
      status: "active",
    },
    {
      id: 2,
      title: "سيد الاختبارات",
      description: "احصل على 100 في 5 اختبارات",
      difficulty: "medium",
      reward: 200,
      progress: 3,
      target: 5,
      icon: "🎯",
      status: "active",
    },
    {
      id: 3,
      title: "الماراثون",
      description: "أكمل 3 دورات كاملة",
      difficulty: "hard",
      reward: 500,
      progress: 1,
      target: 3,
      icon: "🏃",
      status: "active",
    },
    {
      id: 4,
      title: "النجم الصاعد",
      description: "اكسب 1000 XP",
      difficulty: "medium",
      reward: 300,
      progress: 750,
      target: 1000,
      icon: "⭐",
      status: "active",
    },
    {
      id: 5,
      title: "الأسبوع الذهبي",
      description: "حافظ على 7 أيام متتالية",
      difficulty: "medium",
      reward: 250,
      progress: 7,
      target: 7,
      icon: "✨",
      status: "completed",
    },
    {
      id: 6,
      title: "الخبير",
      description: "أكمل دورة احترافية",
      difficulty: "hard",
      reward: 400,
      progress: 0,
      target: 1,
      icon: "🏆",
      status: "locked",
    },
  ];

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "easy":
        return "bg-green-500/20 border-green-500/50 text-green-300";
      case "medium":
        return "bg-yellow-500/20 border-yellow-500/50 text-yellow-300";
      case "hard":
        return "bg-red-500/20 border-red-500/50 text-red-300";
      default:
        return "bg-gray-500/20 border-gray-500/50 text-gray-300";
    }
  };

  const getDifficultyLabel = (difficulty: string) => {
    switch (difficulty) {
      case "easy":
        return "سهل";
      case "medium":
        return "متوسط";
      case "hard":
        return "صعب";
      default:
        return "";
    }
  };

  const handleClaimReward = (challengeId: number) => {
    toast.success("تم الحصول على المكافأة! 🎉");
  };

  const activeChallenges = challenges.filter((c) => c.status === "active");
  const completedChallenges = challenges.filter((c) => c.status === "completed");
  const lockedChallenges = challenges.filter((c) => c.status === "locked");

  return (
    <div className="min-h-screen bg-black text-white p-4 md:p-8 rtl" dir="rtl">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-cyan-400 to-magenta-500 bg-clip-text text-transparent">
          🎯 التحديات والجوائز
        </h1>
        <p className="text-gray-400">
          أكمل التحديات واكسب نقاط XP وجوائز حصرية
        </p>
      </div>

      {/* Streak Section */}
      <Card className="bg-gradient-to-r from-yellow-500/10 to-orange-500/10 border-yellow-500/30 p-6 mb-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Flame className="w-12 h-12 text-yellow-400" />
            <div>
              <h3 className="text-2xl font-bold text-yellow-400">
                {streak.current} 🔥
              </h3>
              <p className="text-gray-400">
                سلسلة يومية متتالية | أفضل: {streak.best}
              </p>
            </div>
          </div>
          <Button className="bg-yellow-500/20 border border-yellow-500/50 text-yellow-400 hover:bg-yellow-500/30">
            <Zap className="w-4 h-4 ml-2" />
            استمر اليوم
          </Button>
        </div>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <Card className="bg-gray-900 border-cyan-500/30 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">التحديات النشطة</p>
              <p className="text-3xl font-bold text-cyan-400">
                {activeChallenges.length}
              </p>
            </div>
            <Target className="w-12 h-12 text-cyan-400/50" />
          </div>
        </Card>

        <Card className="bg-gray-900 border-magenta-500/30 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">المكتملة</p>
              <p className="text-3xl font-bold text-magenta-400">
                {completedChallenges.length}
              </p>
            </div>
            <Zap className="w-12 h-12 text-magenta-400/50" />
          </div>
        </Card>

        <Card className="bg-gray-900 border-green-500/30 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">إجمالي المكافآت</p>
              <p className="text-3xl font-bold text-green-400">2,500 XP</p>
            </div>
            <Zap className="w-12 h-12 text-green-400/50" />
          </div>
        </Card>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="bg-gray-900 border border-cyan-500/30 w-full justify-start mb-6">
          <TabsTrigger
            value="active"
            className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400"
          >
            التحديات النشطة ({activeChallenges.length})
          </TabsTrigger>
          <TabsTrigger
            value="completed"
            className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400"
          >
            المكتملة ({completedChallenges.length})
          </TabsTrigger>
          <TabsTrigger
            value="locked"
            className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400"
          >
            المقفلة ({lockedChallenges.length})
          </TabsTrigger>
        </TabsList>

        {/* Active Challenges */}
        <TabsContent value="active" className="space-y-4">
          {activeChallenges.map((challenge) => (
            <Card
              key={challenge.id}
              className="bg-gray-900 border-cyan-500/30 p-6 hover:border-magenta-500/50 transition-all"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-start gap-4 flex-1">
                  <div className="text-4xl">{challenge.icon}</div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="text-xl font-bold text-white">
                        {challenge.title}
                      </h3>
                      <Badge
                        className={`${getDifficultyColor(challenge.difficulty)}`}
                      >
                        {getDifficultyLabel(challenge.difficulty)}
                      </Badge>
                    </div>
                    <p className="text-gray-400 mb-3">{challenge.description}</p>

                    {/* Progress Bar */}
                    <div className="mb-2">
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm text-gray-400">التقدم</span>
                        <span className="text-sm font-bold text-cyan-400">
                          {challenge.progress} / {challenge.target}
                        </span>
                      </div>
                      <Progress
                        value={(challenge.progress / challenge.target) * 100}
                        className="h-2"
                      />
                    </div>
                  </div>
                </div>

                <div className="text-right ml-4">
                  <div className="text-2xl font-bold text-yellow-400 mb-2">
                    +{challenge.reward} XP
                  </div>
                  {challenge.progress === challenge.target ? (
                    <Button
                      onClick={() => handleClaimReward(challenge.id)}
                      className="bg-green-500/20 border border-green-500/50 text-green-400 hover:bg-green-500/30"
                    >
                      استلام المكافأة
                    </Button>
                  ) : (
                    <Button
                      disabled
                      className="bg-gray-700/20 border border-gray-700/50 text-gray-500"
                    >
                      قيد التقدم
                    </Button>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </TabsContent>

        {/* Completed Challenges */}
        <TabsContent value="completed" className="space-y-4">
          {completedChallenges.map((challenge) => (
            <Card
              key={challenge.id}
              className="bg-gradient-to-r from-green-500/10 to-green-500/5 border-green-500/30 p-6"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-4 flex-1">
                  <div className="text-4xl">{challenge.icon}</div>
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="text-xl font-bold text-white">
                        {challenge.title}
                      </h3>
                      <Badge className="bg-green-500/20 border-green-500/50 text-green-300">
                        ✓ مكتمل
                      </Badge>
                    </div>
                    <p className="text-gray-400">{challenge.description}</p>
                  </div>
                </div>
                <div className="text-right ml-4">
                  <div className="text-2xl font-bold text-green-400">
                    +{challenge.reward} XP
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </TabsContent>

        {/* Locked Challenges */}
        <TabsContent value="locked" className="space-y-4">
          {lockedChallenges.map((challenge) => (
            <Card
              key={challenge.id}
              className="bg-gray-900/50 border-gray-700/50 p-6 opacity-50"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-4 flex-1">
                  <div className="text-4xl opacity-50">{challenge.icon}</div>
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="text-xl font-bold text-gray-400">
                        {challenge.title}
                      </h3>
                      <Badge className="bg-gray-700/50 text-gray-400">
                        🔒 مقفل
                      </Badge>
                    </div>
                    <p className="text-gray-500">{challenge.description}</p>
                    <p className="text-gray-600 text-sm mt-2">
                      أكمل التحديات الأخرى لفتح هذا التحدي
                    </p>
                  </div>
                </div>
                <div className="text-right ml-4">
                  <div className="text-2xl font-bold text-gray-500">
                    +{challenge.reward} XP
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </TabsContent>
      </Tabs>

      {/* Tips Section */}
      <Card className="bg-gradient-to-r from-cyan-500/10 to-magenta-500/10 border-cyan-500/30 p-6 mt-8">
        <h3 className="text-lg font-bold text-cyan-400 mb-3">💡 نصائح</h3>
        <ul className="space-y-2 text-gray-300">
          <li>✓ حافظ على سلسلتك اليومية لكسب مكافآت إضافية</li>
          <li>✓ التحديات الصعبة تعطي مكافآت أكبر</li>
          <li>✓ استخدم XP لفتح محتوى حصري</li>
          <li>✓ شارك إنجازاتك مع الأصدقاء على WhatsApp</li>
        </ul>
      </Card>
    </div>
  );
}
