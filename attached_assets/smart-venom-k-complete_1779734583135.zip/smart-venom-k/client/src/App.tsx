import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import Courses from "@/pages/Courses";
import LessonDetail from "@/pages/LessonDetail";
import AdminDashboard from "@/pages/AdminDashboard";
import AdminDashboardAdvanced from "@/pages/AdminDashboardAdvanced";
import Certificates from "@/pages/Certificates";
import Challenges from "@/pages/Challenges";
import Auth from "@/pages/Auth";
import Quiz from "@/pages/Quiz";
import Store from "@/pages/Store";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import WhatsAppButton from "./components/WhatsAppButton";

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path={"/("} component={Home} />
      <Route path={"/auth"} component={Auth} />
      <Route path={"/courses"} component={Courses} />
      <Route path={"/lesson/:id"} component={LessonDetail} />
      <Route path={"/admin"} component={AdminDashboard} />
      <Route path={"/admin/dashboard"} component={AdminDashboardAdvanced} />
      <Route path={"/certificates"} component={Certificates} />
      <Route path={"/challenges"} component={Challenges} />
      <Route path={"/quiz/:id"} component={Quiz} />
      <Route path={"/store"} component={Store} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="dark"
        // switchable
      >
        <div dir="rtl" className="min-h-screen bg-background text-foreground">
          <TooltipProvider>
            <Toaster />
            <Router />
            <WhatsAppButton />
          </TooltipProvider>
        </div>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
