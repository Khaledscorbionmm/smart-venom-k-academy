import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ShoppingCart, Filter, Search, MessageCircle } from "lucide-react";
import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

interface CartItem {
  courseId: number;
  title: string;
  price: number;
  category: string;
}

export default function Store() {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [cart, setCart] = useState<CartItem[]>([]);
  const [showCart, setShowCart] = useState(false);

  // Fetch courses
  const { data: courses = [] } = trpc.courses.list.useQuery();

  // Filter courses
  const filteredCourses = useMemo(() => {
    return courses.filter((course: any) => {
      const matchesSearch =
        course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        course.description?.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory =
        selectedCategory === "all" || course.category === selectedCategory;
      return matchesSearch && matchesCategory;
    });
  }, [courses, searchQuery, selectedCategory]);

  // Calculate totals
  const subtotal = cart.reduce((sum, item) => sum + item.price, 0);
  const discount = subtotal * 0.1; // 10% discount for bundle
  const total = subtotal - discount;

  const handleAddToCart = (course: any) => {
    const existingItem = cart.find((item) => item.courseId === course.id);
    if (!existingItem) {
      setCart([
        ...cart,
        {
          courseId: course.id,
          title: course.title,
          price: parseFloat(course.price || "369"),
          category: course.category,
        },
      ]);
      toast.success(`تم إضافة ${course.title} إلى السلة`);
    } else {
      toast.error("هذا الكورس موجود بالفعل في السلة");
    }
  };

  const handleRemoveFromCart = (courseId: number) => {
    setCart(cart.filter((item) => item.courseId !== courseId));
    toast.success("تم حذف الكورس من السلة");
  };

  const handleCheckout = () => {
    if (!user) {
      toast.error("يجب تسجيل الدخول أولاً");
      return;
    }

    if (cart.length === 0) {
      toast.error("السلة فارغة");
      return;
    }

    const coursesList = cart.map((item) => `• ${item.title} (${item.price} جنيه)`).join("\n");
    const message = `
مرحباً، أود شراء الدورات التالية:

${coursesList}

الإجمالي: ${subtotal} جنيه
الخصم (10%): -${discount} جنيه
الإجمالي النهائي: ${total} جنيه

اسمي: ${user.name}
البريد الإلكتروني: ${user.email}
    `.trim();

    const encodedMessage = encodeURIComponent(message);
    const whatsappLink = `https://wa.me/201034009418?text=${encodedMessage}`;

    window.open(whatsappLink, "_blank");
    toast.success("تم فتح WhatsApp - أكمل عملية الشراء");
  };

  const categories = [
    { id: "all", label: "جميع الدورات" },
    { id: "programming", label: "البرمجة" },
    { id: "english", label: "اللغة الإنجليزية" },
    { id: "french", label: "اللغة الفرنسية" },
  ];

  return (
    <div className="min-h-screen bg-black text-white p-4 md:p-8 rtl" dir="rtl">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-cyan-400 to-magenta-500 bg-clip-text text-transparent">
          🛍️ متجر الدورات
        </h1>
        <p className="text-gray-400">اختر الدورات التي تناسبك وابدأ التعلم اليوم</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-3">
          {/* Search and Filter */}
          <div className="mb-6 space-y-4">
            <div className="relative">
              <Search className="absolute right-3 top-3 w-5 h-5 text-cyan-400" />
              <Input
                placeholder="ابحث عن دورة..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pr-10 bg-gray-900 border-cyan-500/30 text-white placeholder-gray-500"
              />
            </div>

            {/* Category Tabs */}
            <Tabs value={selectedCategory} onValueChange={setSelectedCategory}>
              <TabsList className="bg-gray-900 border border-cyan-500/30 w-full justify-start">
                {categories.map((cat) => (
                  <TabsTrigger
                    key={cat.id}
                    value={cat.id}
                    className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400"
                  >
                    {cat.label}
                  </TabsTrigger>
                ))}
              </TabsList>
            </Tabs>
          </div>

          {/* Courses Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredCourses.map((course: any) => (
              <Card
                key={course.id}
                className="bg-gray-900 border-cyan-500/30 hover:border-magenta-500/50 transition-all duration-300 overflow-hidden group"
              >
                {/* Course Header */}
                <div className="bg-gradient-to-r from-cyan-500/10 to-magenta-500/10 p-4 border-b border-cyan-500/20">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="text-lg font-bold text-white group-hover:text-cyan-400 transition-colors">
                      {course.title}
                    </h3>
                    <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/50">
                      {course.level}
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-400">{course.description}</p>
                </div>

                {/* Course Body */}
                <div className="p-4 space-y-4">
                  {/* Category Badge */}
                  <div className="flex gap-2">
                    <Badge className="bg-magenta-500/20 text-magenta-400 border-magenta-500/50">
                      {course.category === "programming"
                        ? "برمجة"
                        : course.category === "english"
                          ? "إنجليزي"
                          : "فرنسي"}
                    </Badge>
                  </div>

                  {/* Price */}
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-bold text-cyan-400">
                      {course.price || "369"} جنيه
                    </span>
                    <span className="text-xs text-gray-500">السعر الواحد</span>
                  </div>

                  {/* Add to Cart Button */}
                  <Button
                    onClick={() => handleAddToCart(course)}
                    className="w-full bg-gradient-to-r from-cyan-500 to-magenta-500 hover:from-cyan-600 hover:to-magenta-600 text-white font-bold"
                  >
                    <ShoppingCart className="w-4 h-4 ml-2" />
                    أضف إلى السلة
                  </Button>
                </div>
              </Card>
            ))}
          </div>

          {filteredCourses.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-400 text-lg">لا توجد دورات تطابق البحث</p>
            </div>
          )}
        </div>

        {/* Shopping Cart Sidebar */}
        <div className="lg:col-span-1">
          <Card className="bg-gray-900 border-cyan-500/30 sticky top-4 overflow-hidden">
            {/* Cart Header */}
            <div className="bg-gradient-to-r from-cyan-500/10 to-magenta-500/10 p-4 border-b border-cyan-500/20 flex items-center justify-between">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <ShoppingCart className="w-5 h-5 text-cyan-400" />
                السلة
              </h2>
              <Badge className="bg-magenta-500/20 text-magenta-400">
                {cart.length}
              </Badge>
            </div>

            {/* Cart Items */}
            <div className="p-4 max-h-96 overflow-y-auto space-y-3">
              {cart.length === 0 ? (
                <p className="text-gray-400 text-center py-8">السلة فارغة</p>
              ) : (
                cart.map((item) => (
                  <div
                    key={item.courseId}
                    className="bg-gray-800 p-3 rounded border border-cyan-500/20 hover:border-magenta-500/30 transition-colors"
                  >
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-semibold text-sm text-white flex-1">
                        {item.title}
                      </h4>
                      <button
                        onClick={() => handleRemoveFromCart(item.courseId)}
                        className="text-red-400 hover:text-red-300 text-xs"
                      >
                        ✕
                      </button>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-cyan-400 font-bold">
                        {item.price} جنيه
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Cart Summary */}
            {cart.length > 0 && (
              <div className="p-4 border-t border-cyan-500/20 space-y-3">
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between text-gray-400">
                    <span>الإجمالي:</span>
                    <span>{subtotal} جنيه</span>
                  </div>
                  <div className="flex justify-between text-green-400">
                    <span>خصم (10%):</span>
                    <span>-{discount.toFixed(2)} جنيه</span>
                  </div>
                  <div className="flex justify-between text-lg font-bold text-cyan-400 pt-2 border-t border-cyan-500/20">
                    <span>الإجمالي النهائي:</span>
                    <span>{total.toFixed(2)} جنيه</span>
                  </div>
                </div>

                {/* Checkout Button */}
                <Button
                  onClick={handleCheckout}
                  className="w-full bg-gradient-to-r from-cyan-500 to-magenta-500 hover:from-cyan-600 hover:to-magenta-600 text-white font-bold"
                >
                  <MessageCircle className="w-4 h-4 ml-2" />
                  الشراء عبر WhatsApp
                </Button>

                {/* Info */}
                <p className="text-xs text-gray-500 text-center">
                  سيتم فتح WhatsApp لإكمال عملية الشراء
                </p>
              </div>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}
