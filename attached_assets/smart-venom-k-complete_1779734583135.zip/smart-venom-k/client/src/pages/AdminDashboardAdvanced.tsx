import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import {
  Users,
  TrendingUp,
  ShoppingCart,
  Award,
  BarChart3,
  Settings,
  LogOut,
} from "lucide-react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { toast } from "sonner";

export default function AdminDashboardAdvanced() {
  const { user, logout } = useAuth();
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState("overview");

  // Fetch data
  const { data: courses = [] } = trpc.courses.list.useQuery();

  // Mock data for charts
  const salesData = [
    { month: "يناير", sales: 15000, users: 45 },
    { month: "فبراير", sales: 22000, users: 62 },
    { month: "مارس", sales: 28000, users: 85 },
    { month: "أبريل", sales: 35000, users: 120 },
    { month: "مايو", sales: 42000, users: 165 },
    { month: "يونيو", sales: 48000, users: 210 },
  ];

  const courseStats = [
    { name: "البرمجة", value: 28, fill: "#00ffff" },
    { name: "الإنجليزية", value: 8, fill: "#ff00ff" },
    { name: "الفرنسية", value: 8, fill: "#00ff88" },
  ];

  const handleLogout = async () => {
    await logout();
    navigate("/");
  };

  if (user?.role !== "admin") {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center p-4">
        <Card className="bg-gray-900 border-red-500/30 p-8 text-center">
          <h1 className="text-2xl font-bold text-red-400 mb-4">
            ❌ غير مصرح
          </h1>
          <p className="text-gray-400 mb-6">
            هذه الصفحة متاحة للمديرين فقط
          </p>
          <Button
            onClick={() => navigate("/")}
            className="bg-cyan-500 hover:bg-cyan-600"
          >
            العودة للرئيسية
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white p-4 md:p-8 rtl" dir="rtl">
      {/* Header */}
      <div className="mb-8 flex justify-between items-center">
        <div>
          <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-cyan-400 to-magenta-500 bg-clip-text text-transparent">
            📊 لوحة التحكم المتقدمة
          </h1>
          <p className="text-gray-400">
            مرحباً {user?.name} - إدارة كاملة للمنصة
          </p>
        </div>
        <Button
          onClick={handleLogout}
          className="bg-red-500/20 border border-red-500/50 text-red-400 hover:bg-red-500/30"
        >
          <LogOut className="w-4 h-4 ml-2" />
          تسجيل الخروج
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <Card className="bg-gradient-to-br from-cyan-500/10 to-cyan-500/5 border-cyan-500/30 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">إجمالي المستخدمين</p>
              <p className="text-3xl font-bold text-cyan-400">210</p>
            </div>
            <Users className="w-12 h-12 text-cyan-400/50" />
          </div>
        </Card>

        <Card className="bg-gradient-to-br from-magenta-500/10 to-magenta-500/5 border-magenta-500/30 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">إجمالي المبيعات</p>
              <p className="text-3xl font-bold text-magenta-400">48,000 ج.م</p>
            </div>
            <TrendingUp className="w-12 h-12 text-magenta-400/50" />
          </div>
        </Card>

        <Card className="bg-gradient-to-br from-green-500/10 to-green-500/5 border-green-500/30 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">إجمالي الدورات</p>
              <p className="text-3xl font-bold text-green-400">46</p>
            </div>
            <ShoppingCart className="w-12 h-12 text-green-400/50" />
          </div>
        </Card>

        <Card className="bg-gradient-to-br from-yellow-500/10 to-yellow-500/5 border-yellow-500/30 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">معدل النمو</p>
              <p className="text-3xl font-bold text-yellow-400">+45%</p>
            </div>
            <BarChart3 className="w-12 h-12 text-yellow-400/50" />
          </div>
        </Card>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="bg-gray-900 border border-cyan-500/30 w-full justify-start mb-6">
          <TabsTrigger
            value="overview"
            className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400"
          >
            نظرة عامة
          </TabsTrigger>
          <TabsTrigger
            value="sales"
            className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400"
          >
            المبيعات
          </TabsTrigger>
          <TabsTrigger
            value="users"
            className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400"
          >
            المستخدمون
          </TabsTrigger>
          <TabsTrigger
            value="courses"
            className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400"
          >
            الدورات
          </TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Sales Chart */}
            <Card className="bg-gray-900 border-cyan-500/30 p-6">
              <h3 className="text-xl font-bold text-cyan-400 mb-4">
                📈 المبيعات الشهرية
              </h3>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={salesData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                  <XAxis dataKey="month" stroke="#888" />
                  <YAxis stroke="#888" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#1a1a1a",
                      border: "1px solid #00ffff",
                    }}
                  />
                  <Legend />
                  <Bar dataKey="sales" fill="#00ffff" name="المبيعات (ج.م)" />
                </BarChart>
              </ResponsiveContainer>
            </Card>

            {/* Course Distribution */}
            <Card className="bg-gray-900 border-magenta-500/30 p-6">
              <h3 className="text-xl font-bold text-magenta-400 mb-4">
                🎓 توزيع الدورات
              </h3>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={courseStats}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, value }) => `${name}: ${value}`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {courseStats.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#1a1a1a",
                      border: "1px solid #ff00ff",
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </Card>
          </div>

          {/* Growth Chart */}
          <Card className="bg-gray-900 border-green-500/30 p-6">
            <h3 className="text-xl font-bold text-green-400 mb-4">
              📊 نمو المستخدمين
            </h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={salesData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                <XAxis dataKey="month" stroke="#888" />
                <YAxis stroke="#888" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#1a1a1a",
                    border: "1px solid #00ff88",
                  }}
                />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="users"
                  stroke="#00ff88"
                  name="عدد المستخدمين"
                  strokeWidth={2}
                />
              </LineChart>
            </ResponsiveContainer>
          </Card>
        </TabsContent>

        {/* Sales Tab */}
        <TabsContent value="sales" className="space-y-6">
          <Card className="bg-gray-900 border-cyan-500/30 p-6">
            <h3 className="text-xl font-bold text-cyan-400 mb-4">
              💰 تقرير المبيعات
            </h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center p-4 bg-gray-800 rounded border border-cyan-500/20">
                <span className="text-gray-300">إجمالي المبيعات</span>
                <span className="text-2xl font-bold text-cyan-400">
                  48,000 ج.م
                </span>
              </div>
              <div className="flex justify-between items-center p-4 bg-gray-800 rounded border border-cyan-500/20">
                <span className="text-gray-300">عدد الطلبات</span>
                <span className="text-2xl font-bold text-cyan-400">210</span>
              </div>
              <div className="flex justify-between items-center p-4 bg-gray-800 rounded border border-cyan-500/20">
                <span className="text-gray-300">متوسط الطلب</span>
                <span className="text-2xl font-bold text-cyan-400">
                  228.57 ج.م
                </span>
              </div>
              <div className="flex justify-between items-center p-4 bg-gray-800 rounded border border-cyan-500/20">
                <span className="text-gray-300">الدورة الأكثر مبيعاً</span>
                <Badge className="bg-cyan-500/20 text-cyan-400">
                  Python للمبتدئين
                </Badge>
              </div>
            </div>
          </Card>
        </TabsContent>

        {/* Users Tab */}
        <TabsContent value="users" className="space-y-6">
          <Card className="bg-gray-900 border-magenta-500/30 p-6">
            <h3 className="text-xl font-bold text-magenta-400 mb-4">
              👥 إدارة المستخدمين
            </h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center p-4 bg-gray-800 rounded border border-magenta-500/20">
                <span className="text-gray-300">إجمالي المستخدمين</span>
                <span className="text-2xl font-bold text-magenta-400">210</span>
              </div>
              <div className="flex justify-between items-center p-4 bg-gray-800 rounded border border-magenta-500/20">
                <span className="text-gray-300">المستخدمون النشطون</span>
                <span className="text-2xl font-bold text-magenta-400">165</span>
              </div>
              <div className="flex justify-between items-center p-4 bg-gray-800 rounded border border-magenta-500/20">
                <span className="text-gray-300">المستخدمون الجدد (هذا الشهر)</span>
                <span className="text-2xl font-bold text-magenta-400">45</span>
              </div>
              <div className="flex justify-between items-center p-4 bg-gray-800 rounded border border-magenta-500/20">
                <span className="text-gray-300">معدل الاحتفاظ</span>
                <span className="text-2xl font-bold text-magenta-400">78%</span>
              </div>
            </div>
          </Card>
        </TabsContent>

        {/* Courses Tab */}
        <TabsContent value="courses" className="space-y-6">
          <Card className="bg-gray-900 border-green-500/30 p-6">
            <h3 className="text-xl font-bold text-green-400 mb-4">
              🎓 إدارة الدورات
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div className="p-4 bg-gray-800 rounded border border-green-500/20">
                <p className="text-gray-400 text-sm mb-2">إجمالي الدورات</p>
                <p className="text-3xl font-bold text-green-400">46</p>
              </div>
              <div className="p-4 bg-gray-800 rounded border border-green-500/20">
                <p className="text-gray-400 text-sm mb-2">الدورات النشطة</p>
                <p className="text-3xl font-bold text-green-400">46</p>
              </div>
              <div className="p-4 bg-gray-800 rounded border border-green-500/20">
                <p className="text-gray-400 text-sm mb-2">متوسط التقييم</p>
                <p className="text-3xl font-bold text-green-400">4.8/5</p>
              </div>
            </div>

            <div className="space-y-3">
              <h4 className="text-lg font-bold text-green-400 mb-3">
                الدورات الأكثر شعبية:
              </h4>
              {courses.slice(0, 5).map((course: any) => (
                <div
                  key={course.id}
                  className="flex justify-between items-center p-3 bg-gray-800 rounded border border-green-500/20"
                >
                  <span className="text-gray-300">{course.title}</span>
                  <Badge className="bg-green-500/20 text-green-400">
                    {course.level}
                  </Badge>
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Footer */}
      <div className="mt-8 p-4 bg-gray-900 border border-cyan-500/20 rounded text-center text-gray-400 text-sm">
        <p>
          آخر تحديث: {new Date().toLocaleString("ar-EG")} | Smart Venom K
          Admin Dashboard
        </p>
      </div>
    </div>
  );
}
