import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2, BookOpen, Zap, Lock } from "lucide-react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";

export default function Courses() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  
  const { data: courses, isLoading } = trpc.courses.list.useQuery(undefined, {
    enabled: isAuthenticated,
  });
  
  const { data: stats } = trpc.stats.getMyStats.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-xl mb-4">يجب عليك تسجيل الدخول أولاً</p>
          <Button className="btn-neon">تسجيل الدخول</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="glass-card border-b border-border sticky top-0 z-40">
        <div className="container mx-auto px-4 py-6">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold neon-text">الدورات التعليمية</h1>
              <p className="text-text-secondary mt-2">مرحبا {user?.name}</p>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-neon-cyan">{stats?.totalXp || 0}</div>
              <div className="text-sm text-text-secondary">نقاط XP</div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-12">
        {isLoading ? (
          <div className="flex justify-center items-center min-h-96">
            <Loader2 className="w-8 h-8 animate-spin text-neon-cyan" />
          </div>
        ) : !courses || courses.length === 0 ? (
          <div className="text-center py-12">
            <BookOpen className="w-16 h-16 mx-auto mb-4 text-text-secondary opacity-50" />
            <p className="text-xl text-text-secondary">لا توجد دورات متاحة حالياً</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {courses.map((course) => (
              <Card
                key={course.id}
                className="glass-card p-6 border border-border hover:border-neon-cyan/50 transition-all cursor-pointer group"
                onClick={() => navigate(`/course/${course.id}`)}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <span className="inline-block px-3 py-1 rounded text-xs font-mono text-neon-green bg-neon-green/10 mb-3">
                      {course.level === "beginner" && "مبتدئ"}
                      {course.level === "intermediate" && "متوسط"}
                      {course.level === "advanced" && "متقدم"}
                    </span>
                    <h3 className="text-xl font-bold group-hover:text-neon-cyan transition-colors">
                      {course.title}
                    </h3>
                  </div>
                </div>
                
                <p className="text-text-secondary mb-4 text-sm line-clamp-2">
                  {course.description || "دورة تعليمية شاملة"}
                </p>
                
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-sm text-text-secondary">
                    <BookOpen className="w-4 h-4" />
                    <span>دروس متعددة</span>
                  </div>
                  
                  <div className="w-full h-2 bg-bg-tertiary rounded-full overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-neon-cyan to-neon-magenta w-1/3 group-hover:w-1/2 transition-all duration-500"></div>
                  </div>
                  
                  <Button className="w-full btn-neon text-sm mt-4">
                    ابدأ الآن
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
